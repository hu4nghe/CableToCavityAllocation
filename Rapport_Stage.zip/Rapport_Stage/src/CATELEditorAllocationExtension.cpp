#include "CATELEditorAllocationExtension.h"

int CATELEditorAllocationExtension::DblCompare(double a, double b)
{
	double Diff = std::fabs(a - b);
	if (Diff < CATEpsg) return 0;
	else if (b - a > CATEpsg) return -1;
	else return 1;
};
int CATELEditorAllocationExtension::CATMathPoint2DCompare(const CATMathPoint2D& lhs, const CATMathPoint2D& rhs)
{
	int XCompare = DblCompare(lhs.GetX(), rhs.GetX());
	if (XCompare != 0) return XCompare;
	else return DblCompare(lhs.GetY(), rhs.GetY());
}